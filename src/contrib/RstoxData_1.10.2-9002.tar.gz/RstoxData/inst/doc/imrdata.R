## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)


## ----pullData-----------------------------------------------------------------

#' Download data set from NMD biotic
#' @description 
#'  Downloads a data set from latest snapshot in NMD biotic v3, 
#'  and saves it to a file as XML (namespace: http://www.imr.no/formats/nmdbiotic/v3.1)
#' @param targetfile filename to save dataset to
#' @param path path to dataset.
#' @param url address to NMD biotic v.3 (defaults to production address pr. Aug 2023)
#' @param port port to use (defaults 8080)
#' @param append if TRUE appends missions to existing file. If false writes to a new file and adds start and end missions-tag
#' @examples 
#'  \dontrun{pullDataSet("test.xml", "Forskningsfartøy/2023/Johan Hjort_LDGJ/2023002005")}
pullDataSet <- function(targetfile, path, url="http://tomcat7.imr.no", port=8080, append=F){
  
  if (file.exists(targetfile) & !append){
    stop(paste("File", targetfile, "already exists"))
  }
  
  basepath <- "apis/nmdapi/biotic/v3"
  datasetpath <- URLencode(paste(basepath, path, "dataset", sep="/"))
  snapshotpath <- URLencode(paste(basepath, path, "snapshot", sep="/"))
  
  snapshots <- httr::GET(url, port=port, path=snapshotpath, query="version=3.1")
  if (snapshots$status_code == 404){
    stop(paste("Found no snapshots for dataset at:", snapshotpath))
  }
  
  snapshotlist <- xml2::as_list(xml2::read_xml(rawToChar(snapshots$content)))[[1]]
  snapshotvector <- unlist(lapply(snapshotlist, function(x){x[[1]][[1]]}))
  latestsnapsot <- sort(snapshotvector, decreasing = T)[1]
  
  latestsnapshotpath <- URLencode(paste(snapshotpath, latestsnapsot, sep="/"))
  mission <- httr::GET(url, port=port, path=latestsnapshotpath, query="version=3.1")
  
  content <- strsplit(rawToChar(mission$content), "\n")[[1]]
  starttag <- "<missions xmlns=\"http://www.imr.no/formats/nmdbiotic/v3.1\">"
  endtag <- "</missions>"
  
  if (!append){
    write(content[[1]], file=targetfile)
    write(starttag, file=targetfile, append = T)
  }
  if (length(content) > 1){
    for (i in 2:length(content)){
      write(content[[i]], file=targetfile, append = T)
    }
  }
  if (!append){
    write(endtag, file=targetfile, append = T)    
  }

}


## -----------------------------------------------------------------------------
#' Look up data paths for a cruise
#' @param vessel name of vessel
#' @param cruise cruise number
#' @param url address to cruise API (defaults to production address pr. Aug 2023)
#' @param port port to use (defaults 8080)
#' @examples 
#'  \dontrun{getCruisePaths("Johan Hjort","2023002005")}
getCruisePaths <- function(vessel, cruise, url="http://tomcat7.imr.no", port=8080){
  basepath <- "apis/nmdapi/cruise/v2"
  query <- list(type="findByCruise",
                shipname=vessel,
                cruisenr=cruise)
  cruiseIds <- httr::GET(url, port=port, path=basepath, query=query)
  
  if (cruiseIds$status_code == 404){
    stop(paste("Found no data for cruise", cruise), "at", vessel)
  }
  
  content <- xml2::read_xml(cruiseIds$content)
  rows<-xml2::xml_children(xml2::xml_child(content))
  
  result <- list()
  for (s in rows){
    name <- xml2::xml_attr(s, "name")
    result[[name]] <- xml2::xml_text(s, trim = T)
  }

  return(result)
  
}


## -----------------------------------------------------------------------------
#' Find data set paths for all data sets within a set of missiontypes and years
#' @param years vector fo years to find paths for
#' @param missiontypenames vector of missiontypenames to find paths for
#' @param url address to cruise API (defaults to production address pr. Aug 2023)
#' @param port port to use (defaults 8080)
#' @examples
#'  \dontrun{getMissionTypePaths(c("Referanseflåten-Hav"), c(2021))}
getMissionTypePaths <- function(missiontypenames, years, url="http://tomcat7.imr.no", port=8080){
  basepath <- "apis/nmdapi/biotic/v3"
  #datasetpath <- URLencode(paste(basepath, path, "dataset", sep="/"))
  #snapshotpath <- URLencode(paste(basepath, path, "snapshot", sep="/"))
  
  paths <- c()
  for (m in missiontypenames){
    for (y in years){
      platformspath <- URLencode(paste(basepath, m, y, sep="/"))
      response <- httr::GET(url, port=port, path=platformspath)
      if (response$status_code != 200){
        stop(paste("Error in API call. Could not list platforms for ", m, y))
      }

      platforms <- c()
      content <- xml2::read_xml(rawToChar(response$content))
      for (child in xml2::xml_children(content)){
        for (grandchild in xml2::xml_children(child)){
          if (xml2::xml_attr(grandchild, "name")=="platformpath"){
            platforms <- c(platforms, xml2::xml_text(grandchild))
          }
        }
      }

      for (p in platforms){
        deliverypath <- URLencode(paste(basepath, m, y, p, sep="/"))
        response <- httr::GET(url, port=port, path=deliverypath)
        
        if (response$status_code != 200){
          stop(paste("Error in API call. Could not list missions for ", m, y, p))
        }
        content <- xml2::read_xml(rawToChar(response$content))
        deliveries <- c()
        for (child in xml2::xml_children(content)){
          for (grandchild in xml2::xml_children(child)){
            if (xml2::xml_attr(grandchild, "name")=="delivery"){
              deliveries <- c(deliveries, xml2::xml_text(grandchild))
            }
          }
        }
        
        for (d in deliveries){
          paths <- c(paths, paste(m, y, p, d, sep="/"))
        }
      }
    }
  }
  
  return(paths)
}

## -----------------------------------------------------------------------------
#' Fetches biotic-data for a set of paths and compiles them into one data file
#' @param targetfile name of xml file to be created
#' @param paths vector of paths to fetch
#' @param overwrite if TRUE any existing 'targetfile' will be overwritten.
#' @param namespace namespace to declare for the file
#'  \dontrun{pullBioticData("test.xml", c("Forskningsfartøy/2023/Johan Hjort_LDGJ/2023002005", "Forskningsfartøy/2023/Johan Hjort_LDGJ/2023002006"))}
pullBioticData <- function(targetfile, paths, overwrite=F){
  
  if (file.exists(targetfile) & !overwrite){
    stop(paste("File", targetfile, "already exists."))
  }
  
  starttag <- "<missions xmlns=\"http://www.imr.no/formats/nmdbiotic/v3.1\">"
  endtag <- "</missions>"
  
  write(starttag, file=targetfile)
  for (p in paths){
    tryCatch({    
          pullDataSet(targetfile, p, append = T)
          message(paste("pulling biotic data for", p))
    }, error = function(e){warning(paste("Could not pull biotic data for", p, e))})

  }
  write(endtag, file=targetfile, append = T)

}


## ----convertStoxBiotic--------------------------------------------------------
ecosystem_sb <- RstoxData::StoxBiotic(RstoxData::ecosystemsurvey_example)

## -----------------------------------------------------------------------------
ecosystem_sb_pos <- RstoxData::AddToStoxBiotic(ecosystem_sb, RstoxData::ecosystemsurvey_example, c("latitudestart", "latitudeend", "longitudestart", "longitudeend"))

## -----------------------------------------------------------------------------
ecosystem_sb_pos_haul <- RstoxData::AddToStoxBiotic(ecosystem_sb, RstoxData::ecosystemsurvey_example, c("latitudestart", "latitudeend", "longitudestart", "longitudeend"), "Lowest")

## -----------------------------------------------------------------------------
ecosystem_sb_individual <- RstoxData::MergeStoxBiotic(ecosystem_sb_pos_haul)

## -----------------------------------------------------------------------------
ecosystem_sb_sample <- RstoxData::MergeStoxBiotic(ecosystem_sb_pos_haul, "Sample")

## -----------------------------------------------------------------------------
ecosystem_nmdb_individual <- RstoxData::PrepareNmdBioticTable(RstoxData::ecosystemsurvey_example, "Individual")

## -----------------------------------------------------------------------------
ecosystem_nmdb_individual_ids <- RstoxData::PrepareNmdBioticTable(RstoxData::ecosystemsurvey_example, "Individual", T)
print(paste("Individual ids:",length(unique(ecosystem_nmdb_individual_ids$Individual))))
print(paste("Number of rows:", nrow(ecosystem_nmdb_individual)))

## -----------------------------------------------------------------------------
ecosystem_nmdb_prey_ids <- RstoxData::PrepareNmdBioticTable(RstoxData::ecosystemsurvey_example, "Prey", T)

## -----------------------------------------------------------------------------
filterExpression <- list()
filterExpression[["ecosystemsurvey.xml"]] <- list()
filterExpression[["ecosystemsurvey.xml"]][["catchsample"]] <- c("commonname == 'torsk'")
filterExpression[["ecosystemsurvey.xml"]][["individual"]] <- c("length > .20")

## -----------------------------------------------------------------------------
filteredData <- RstoxData::FilterBiotic(RstoxData::ecosystemsurvey_example, filterExpression)

## -----------------------------------------------------------------------------
table(filteredData$ecosystemsurvey.xml$catchsample$commonname)

## -----------------------------------------------------------------------------
print(paste("Retained", nrow(filteredData$ecosystemsurvey.xml$individual), "out of", nrow(RstoxData::ecosystemsurvey_example$ecosystemsurvey.xml$individual), "individuals")) 

## -----------------------------------------------------------------------------
print(paste("Retained", nrow(filteredData$ecosystemsurvey.xml$fishstation), "out of", nrow(RstoxData::ecosystemsurvey_example$ecosystemsurvey.xml$fishstation), "stations")) 

## -----------------------------------------------------------------------------
filteredUp <- RstoxData::FilterBiotic(RstoxData::ecosystemsurvey_example, filterExpression, T)

## -----------------------------------------------------------------------------
table(filteredUp$ecosystemsurvey.xml$catchsample$commonname)

