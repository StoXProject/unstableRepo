## ----include, include=FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, include=FALSE-----------------------------------------------------
library(RstoxFDA)

## ----docfunction, echo=TRUE---------------------------------------------------
?RstoxFDA::AnalyticalPopulationEstimate

## ----docformat, echo=TRUE-----------------------------------------------------
?RstoxFDA::AnalyticalPopulationEstimateData

## ----installTestPackages, eval=FALSE------------------------------------------
# install.packages(c("RstoxData", "RstoxBase", "RstoxFramework", "RstoxFDA"), repos = c("https://stoxproject.github.io/testingRepo/"))

## ----installProductionPackages, eval=FALSE------------------------------------
# remove.packages(c("RstoxData", "RstoxBase", "RstoxFramework", "RstoxFDA"))
# install.packages(c("RstoxData", "RstoxBase", "RstoxFramework", "RstoxFDA"), repos = c("https://stoxproject.github.io/repo/"))

## ----ReadPSUsamplingParameters------------------------------------------------
DefinitionMethod = "ResourceFile"
FileName = system.file("testresources", "lotteryParameters", "lotteryDesignNSHstrata.txt", package="RstoxFDA")
PSUparameters <- RstoxFDA::ReadPSUSamplingParameters(FileName)

## ----inspectPSUsamplingParameters---------------------------------------------
head(PSUparameters$SelectionTable)

## ----inspectPSUsamplingParametersUnsampled------------------------------------
head(PSUparameters$SelectionTable[is.na(PSUparameters$SelectionTable$SamplingUnitId),])

## ----inspectPSUstratification-------------------------------------------------
PSUparameters$StratificationVariables

## ----DefineINDsamplingParameters----------------------------------------------
StoxBioticData = RstoxFDA::CatchLotteryExample
DefinitionMethod = "SRS"
Parameters = c("IndividualSex", "IndividualAge")
indParameters <- RstoxFDA::ComputeIndividualSamplingParameters(StoxBioticData = StoxBioticData, DefinitionMethod = DefinitionMethod, Parameters=Parameters)

## ----inspectIndParams---------------------------------------------------------
head(indParameters$SelectionTable)

## ----DefineINDsamplingParametersNoNa------------------------------------------
StoxBioticData = RstoxFDA::CatchLotteryExample
DefinitionMethod = "SRS"
Parameters = c("IndividualAge")
indParametersNoNA <- RstoxFDA::ComputeIndividualSamplingParameters(StoxBioticData = StoxBioticData, DefinitionMethod = DefinitionMethod, Parameters=Parameters)

## ----ageNaIndiviuals----------------------------------------------------------
head(indParameters$SelectionTable[!(indParameters$SelectionTable$IndividualId %in% indParametersNoNA$SelectionTable$IndividualId),])

## ----AssignPSUsamplingParameters----------------------------------------------
PSUSamplingParametersData = PSUparameters
StoxBioticData = RstoxFDA::CatchLotteryExample
SamplingUnitId = "serialnumber"
DataRecordId = "Haul"
DefinitionMethod = "MissingAtRandom"
PSUassigment = RstoxFDA::AssignPSUSamplingParameters(DefinitionMethod=DefinitionMethod, StoxBioticData=StoxBioticData, PSUSamplingParametersData=PSUparameters, SamplingUnitId=SamplingUnitId, DataRecordId=DataRecordId)

## ----viewPSUassigment---------------------------------------------------------
head(PSUassigment$SelectionTable)

## ----EstimatePSU--------------------------------------------------------------
StoxBioticData = RstoxFDA::CatchLotteryExample
IndividualSamplingParametersData = indParameters
DomainVariables = c("IndividualAge")
Variables = c("IndividualRoundWeight", "IndividualTotalLength")
psuEstimates <- RstoxFDA::AnalyticalPSUEstimate(StoxBioticData=StoxBioticData, IndividualSamplingParametersData = IndividualSamplingParametersData, DomainVariables=DomainVariables, Variables=Variables)

## ----inspectAbundancePSU------------------------------------------------------
head(psuEstimates$Abundance)

## ----inspectDomains-----------------------------------------------------------
psuEstimates$DomainVariables

## ----inspectTotalsPsuEstimates------------------------------------------------
head(psuEstimates$Variables)

## ----EstimatePopulation-------------------------------------------------------
PSUSamplingParametersData = PSUassigment
AnalyticalPSUEstimateData = psuEstimates
populationEstimates = RstoxFDA::AnalyticalPopulationEstimate(PSUSamplingParametersData, AnalyticalPSUEstimateData = AnalyticalPSUEstimateData)

## ----inspectPopulationAbundanceAndVariables-----------------------------------
head(populationEstimates$Abundance)
head(populationEstimates$Variables)

## ----inspectDomainVariablesPSUs-----------------------------------------------
populationEstimates$DomainVariables

## ----inspectCovarMatrix-------------------------------------------------------

head(populationEstimates$AbundanceCovariance)


## ----RatioEstimateTotal-------------------------------------------------------
AnalyticalPopulationEstimateData = populationEstimates
StoxLandingData = RstoxFDA::CatchLotteryLandingExample
WeightVariable = "IndividualRoundWeight"
Method = "TotalDomainWeight"
ratioEst <- RstoxFDA::AnalyticalRatioEstimate(AnalyticalPopulationEstimateData=AnalyticalPopulationEstimateData, StoxLandingData = StoxLandingData, WeightVariable = WeightVariable, Method = Method, StratificationVariables = "Species")

## ----insepctRatioEstimate-----------------------------------------------------
merge(ratioEst$Abundance, populationEstimates$Abundance, by=c("Stratum", "Domain"), suffix=c(".ratioEst", ".designEst"))

## ----ReportAnalyticalCatchAtAge-----------------------------------------------
AnalyticalPopulationEstimateData = ratioEst
PlusGroup = 9
IntervalWidth = .9
Decimals = 0
caaReport <- ReportAnalyticalCatchAtAge(AnalyticalPopulationEstimateData = AnalyticalPopulationEstimateData, PlusGroup = PlusGroup, IntervalWidth = IntervalWidth, Decimals = Decimals, "10^6 individuals")
caaReport$NbyAge

## ----PlotCatchAtAgeTotals-----------------------------------------------------
ReportFdaCatchAtAgeData = caaReport
PlotCatchAtAgeTotals(ReportFdaCatchAtAgeData = ReportFdaCatchAtAgeData)

## ----ageSexdomain-------------------------------------------------------------
# Redo psu estimates with new domain definition
DomainVariables = c("IndividualAge", "IndividualSex")
psuEstimates <- RstoxFDA::AnalyticalPSUEstimate(StoxBioticData=StoxBioticData, IndividualSamplingParametersData = IndividualSamplingParametersData, DomainVariables=DomainVariables, Variables=Variables)

# Redo population estimate
AnalyticalPSUEstimateData = psuEstimates
populationEstimates = RstoxFDA::AnalyticalPopulationEstimate(PSUSamplingParametersData, AnalyticalPSUEstimateData = AnalyticalPSUEstimateData)

# Redo ratio estimate
AnalyticalPopulationEstimateData = populationEstimates
ratioEst <- RstoxFDA::AnalyticalRatioEstimate(AnalyticalPopulationEstimateData=AnalyticalPopulationEstimateData, StoxLandingData = StoxLandingData, WeightVariable = WeightVariable, Method = Method, StratificationVariables = "Species")

# Report
AnalyticalPopulationEstimateData = ratioEst
caaReport <- ReportAnalyticalCatchAtAge(AnalyticalPopulationEstimateData = AnalyticalPopulationEstimateData, PlusGroup = PlusGroup, IntervalWidth = IntervalWidth, Decimals = Decimals, "10^6 individuals")

# Plot
ReportFdaCatchAtAgeData = caaReport
PlotCatchAtAgeTotals(ReportFdaCatchAtAgeData = ReportFdaCatchAtAgeData)

## ----inspectMultiColumnDomains------------------------------------------------
head(AnalyticalPopulationEstimateData$DomainVariables)

## ----addQuarter---------------------------------------------------------------
quarter <- RstoxFDA::DefinePeriod(TemporalCategory = "Quarter")
StoxBioticDataWquarter <- RstoxFDA::AddPeriodStoxBiotic(StoxBioticData, quarter, "Quarter")
StoxLandingDataWquarter <- RstoxFDA::AddPeriodStoxLanding(StoxLandingData, quarter, "Quarter")

## ----paramsPsuDomains---------------------------------------------------------
DomainVariables = c("IndividualAge")
PSUDomainVariables <- c("Quarter")
StoxBioticData <- StoxBioticDataWquarter
StoxLandingData <- StoxLandingDataWquarter
psuEstimates <- RstoxFDA::AnalyticalPSUEstimate(StoxBioticData=StoxBioticData, IndividualSamplingParametersData = IndividualSamplingParametersData, DomainVariables=DomainVariables, Variables=Variables, PSUDomainVariables = PSUDomainVariables)

## ----estimateWpsuDomains------------------------------------------------------
# Redo psu estimates with new domain definition
DomainVariables = c("IndividualAge")
PSUDomainVariables <- c("Quarter")
StoxBioticData <- StoxBioticDataWquarter
StoxLandingData <- StoxLandingDataWquarter
psuEstimates <- RstoxFDA::AnalyticalPSUEstimate(StoxBioticData=StoxBioticData, IndividualSamplingParametersData = IndividualSamplingParametersData, DomainVariables=DomainVariables, Variables=Variables, PSUDomainVariables = PSUDomainVariables)

# Redo population estimate
AnalyticalPSUEstimateData = psuEstimates
populationEstimates = RstoxFDA::AnalyticalPopulationEstimate(PSUSamplingParametersData, AnalyticalPSUEstimateData = AnalyticalPSUEstimateData)

# Redo ratio estimate
AnalyticalPopulationEstimateData = populationEstimates
ratioEst <- RstoxFDA::AnalyticalRatioEstimate(AnalyticalPopulationEstimateData=AnalyticalPopulationEstimateData, StoxLandingData = StoxLandingData, WeightVariable = WeightVariable, Method = Method, StratificationVariables = "Species")

# Report
AnalyticalPopulationEstimateData = ratioEst
caaReport <- ReportAnalyticalCatchAtAge(AnalyticalPopulationEstimateData = AnalyticalPopulationEstimateData, PlusGroup = PlusGroup, IntervalWidth = IntervalWidth, Decimals = Decimals, "10^6 individuals")

# Plot
ReportFdaCatchAtAgeData = caaReport
PlotCatchAtAgeTotals(ReportFdaCatchAtAgeData = ReportFdaCatchAtAgeData)

