## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(RstoxFDA)

## ----docfunction, echo=TRUE---------------------------------------------------
?RstoxFDA::ReportFdaLandings

## ----docformat, echo=TRUE-----------------------------------------------------
?RstoxFDA::ReportFdaLandingData

